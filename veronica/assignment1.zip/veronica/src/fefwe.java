//public class ElectronicStore {
//    String name;
//
//    public ElectronicStore(String name){
//        this.name = name;
//    }
//    String name;
////    Desktop [] desktops;
////    Laptop[] laptops;
////    Fridge [] fridges;
////    static final int MAX_DESKTOPS = 20;
//    Desktop desktops [] = new Desktop[3];
//    Laptop laptops [] = new Laptop[3];
//    Fridge fridges [] = new Fridge[3];
//
//    public ElectronicStore (String name){
//        this.name = name;
//    }
//
//    public String printStock(String name){
//       desktops[0] =  new Desktop(3.5,8,500,true);
//       desktops[1] =  new Desktop(4.5,10,600,false);
//       desktops[2] =  new Desktop(5.5,12,800,false);
//
//
//       laptops[0] = new Laptop(3.1,32,500,true, 7);
//       laptops[1] = new Laptop(4.1,64,800,true, 9);
//       laptops[2] = new Laptop(5.1,128,900,false, 13);
//
//       fridges [0] =  new Fridge (15.6, false, "gray");
//       fridges [1] =  new Fridge (13, true, "orange");
//       fridges [2] =  new Fridge (13.5, false, "black");
//
//       for (int i = 0; i < 3; i++) {
//           return desktops[i];
//       }
//
//
//
//
//
//
//
////       desktops = new Desktop[MAX_DESKTOPS];
//    }
//}
